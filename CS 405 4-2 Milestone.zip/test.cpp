// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <stdexcept>
#include <cassert>
#include <cstdlib>
#include <ctime>

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //    FAIL();
 //}

 // Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CheckMaxSize)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(11);

    ASSERT_GE(collection->max_size(), 0);
    ASSERT_GE(collection->max_size(), 1);
    ASSERT_GE(collection->max_size(), 5);
    ASSERT_GE(collection->max_size(), 10);
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CheckCapacity)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    ASSERT_GE(collection->capacity(), 0);

    add_entries(11);

    ASSERT_GE(collection->capacity(), 1);
    ASSERT_GE(collection->capacity(), 5);
    ASSERT_GE(collection->capacity(), 10);
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIsGreater)
{
    add_entries(1);

    int previousSize = collection->size();
    collection->resize(10);
    ASSERT_TRUE(collection->size() > previousSize);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeIsLesser)
{
    add_entries(10);

    int previousSize = collection->size();

    collection->resize(1);
    ASSERT_TRUE(collection->size() < previousSize);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeIsZero)
{
    add_entries(10);

    int previousSize = collection->size();

    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearCollection)
{
    add_entries(10);

    collection->clear();
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseCheck)
{
    add_entries(10);

    collection->erase(collection->begin(), collection->end());
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncrease)
{
    add_entries(10);

    int prevCapacity = collection->capacity();
    int prevSize = collection->size();

    collection->reserve(20);

    ASSERT_TRUE(collection->size() == prevSize);
    ASSERT_TRUE(collection->capacity() > prevCapacity);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRange)
{
    std::vector<int> myvector(10);
    EXPECT_THROW(myvector.at(20), std::out_of_range); // added bounds-check test for negative test case
}

// Positive custom test to verify that pushing a value increases the vector size by 1
TEST_F(CollectionTest, PushBackIncreasesSize)
{
    size_t originalSize = collection->size();
    collection->push_back(5);  // push one element
    ASSERT_EQ(collection->size(), originalSize + 1);  // confirm size increases
}

// Negative custom test to verify accessing negative index throws out_of_range
TEST_F(CollectionTest, AccessNegativeIndexThrows)
{
    EXPECT_THROW(collection->at(-1), std::out_of_range); // using .at() ensures exception is thrown
}
